// M Star Watch Gallery — front-end demo.
// Replace WHATSAPP_NUMBER with your WhatsApp number including country code, digits only.
// Example Bangladesh: 8801XXXXXXXXX (do not include +, spaces or dashes).
const WHATSAPP_NUMBER = "8801XXXXXXXXX";

const products = [
  {id:1,name:"Midnight Classic",category:"Classic",price:1250,tag:"Bestseller",description:"A clean, versatile design for everyday confidence.",image:"https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=900&q=85"},
  {id:2,name:"Golden Hour",category:"Luxury",price:1850,tag:"Featured",description:"Warm gold tones with a refined, timeless feel.",image:"https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=900&q=85"},
  {id:3,name:"Urban Digital",category:"Digital",price:950,tag:"Everyday",description:"A sporty digital look made for an active routine.",image:"https://images.unsplash.com/photo-1617043786394-f977fa12eddf?auto=format&fit=crop&w=900&q=85"},
  {id:4,name:"Heritage Silver",category:"Classic",price:1550,tag:"New style",description:"Understated silver styling that pairs with anything.",image:"https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=85"},
  {id:5,name:"Sport Edge",category:"Sport",price:1150,tag:"Active",description:"Bold details for weekends, workouts and beyond.",image:"https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?auto=format&fit=crop&w=900&q=85"},
  {id:6,name:"Royal Black",category:"Luxury",price:2250,tag:"Statement",description:"A confident black finish for evenings and occasions.",image:"https://images.unsplash.com/photo-1614164185128-e4ec99c436d7?auto=format&fit=crop&w=900&q=85"},
  {id:7,name:"Ocean Motion",category:"Sport",price:1450,tag:"Popular",description:"A bold, modern profile with a laid-back feel.",image:"https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=900&q=85"},
  {id:8,name:"Minimal Muse",category:"Classic",price:1350,tag:"Minimal",description:"A minimalist timepiece that lets your style speak.",image:"https://images.unsplash.com/photo-1495856458515-0637185db551?auto=format&fit=crop&w=900&q=85"}
];

let activeCategory = "All";
let cart = [];
let nextProductId = 9;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const money = (amount) => "৳" + Number(amount).toLocaleString("en-BD");

function safeText(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[char]));
}

function getFilteredProducts() {
  const search = $("#searchInput").value.trim().toLowerCase();
  let list = products.filter((product) => {
    const categoryMatch = activeCategory === "All" || product.category === activeCategory;
    const searchMatch = `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(search);
    return categoryMatch && searchMatch;
  });
  const sort = $("#sortSelect").value;
  if (sort === "low") list.sort((a,b) => a.price - b.price);
  if (sort === "high") list.sort((a,b) => b.price - a.price);
  if (sort === "name") list.sort((a,b) => a.name.localeCompare(b.name));
  return list;
}

function renderProducts() {
  const list = getFilteredProducts();
  $("#productGrid").innerHTML = list.map((product) => `
    <article class="product-card">
      <div class="product-image-wrap" data-details="${product.id}" tabindex="0" role="button" aria-label="View ${safeText(product.name)} details">
        <img src="${safeText(product.image)}" alt="${safeText(product.name)} watch" loading="lazy" onerror="this.src='https://placehold.co/600x700/e6e1d8/5b5142?text=M+Star+Watch'">
        <span class="product-tag">${safeText(product.tag || product.category)}</span>
        <button class="quick-view" data-details="${product.id}">QUICK VIEW ↗</button>
      </div>
      <div class="product-info">
        <span class="product-category">${safeText(product.category)}</span>
        <div class="product-title-row"><h3 class="product-title">${safeText(product.name)}</h3><span class="product-price">${money(product.price)}</span></div>
        <p class="product-description">${safeText(product.description)}</p>
        <div class="product-actions"><button class="add-cart" data-add="${product.id}">Add to bag +</button><button class="details-button" data-details="${product.id}">Details</button></div>
      </div>
    </article>`).join("");
  $("#emptyState").classList.toggle("hidden", list.length !== 0);
}

function openProductDetails(id) {
  const product = products.find((item) => item.id === Number(id));
  if (!product) return;
  $("#productModalContent").innerHTML = `
    <div class="modal-product-layout">
      <img src="${safeText(product.image)}" alt="${safeText(product.name)}" onerror="this.src='https://placehold.co/600x700/e6e1d8/5b5142?text=M+Star+Watch'">
      <div><p class="eyebrow">${safeText(product.category)} COLLECTION</p><h2 id="modalTitle">${safeText(product.name)}</h2>
      <div class="modal-product-price">${money(product.price)}</div><p class="modal-product-description">${safeText(product.description)} Contact us to confirm availability, delivery options and product details before ordering.</p>
      <button class="button button-gold" data-modal-add="${product.id}">Add to bag <span>+</span></button>
      <button class="button button-outline" data-direct-order="${product.id}">Ask on WhatsApp <span>↗</span></button></div>
    </div>`;
  $("#productModalBackdrop").classList.remove("hidden");
  document.body.classList.add("no-scroll");
}

function addToCart(id) {
  const product = products.find((item) => item.id === Number(id));
  if (!product) return;
  const existing = cart.find((item) => item.id === product.id);
  if (existing) existing.quantity += 1;
  else cart.push({...product, quantity:1});
  renderCart();
  showToast(`${product.name} added to your bag`);
}

function changeQuantity(id, change) {
  const item = cart.find((product) => product.id === Number(id));
  if (!item) return;
  item.quantity += change;
  if (item.quantity <= 0) cart = cart.filter((product) => product.id !== Number(id));
  renderCart();
}

function renderCart() {
  const count = cart.reduce((total,item) => total + item.quantity, 0);
  const subtotal = cart.reduce((total,item) => total + item.price * item.quantity, 0);
  $("#cartCount").textContent = count;
  $("#drawerCount").textContent = `(${count})`;
  $("#cartSubtotal").textContent = money(subtotal);
  $("#cartItems").innerHTML = cart.map((item) => `
    <div class="cart-row"><img src="${safeText(item.image)}" alt="${safeText(item.name)}" onerror="this.src='https://placehold.co/200x240/e6e1d8/5b5142?text=Watch'">
      <div><h4>${safeText(item.name)}</h4><p>${money(item.price)}</p><div class="quantity-controls"><button data-quantity="${item.id}" data-change="-1" aria-label="Decrease quantity">−</button><span>${item.quantity}</span><button data-quantity="${item.id}" data-change="1" aria-label="Increase quantity">+</button></div></div>
      <button class="remove-item" data-remove="${item.id}">Remove</button></div>`).join("");
  $("#cartEmpty").classList.toggle("hidden", count > 0);
  $("#cartFooter").classList.toggle("hidden", count === 0);
}

function openCart() {
  $("#cartDrawer").classList.add("open");
  $("#drawerBackdrop").classList.add("open");
  $("#cartDrawer").setAttribute("aria-hidden","false");
  document.body.classList.add("no-scroll");
}
function closeCart() {
  $("#cartDrawer").classList.remove("open");
  $("#drawerBackdrop").classList.remove("open");
  $("#cartDrawer").setAttribute("aria-hidden","true");
  if ($("#productModalBackdrop").classList.contains("hidden") && $("#adminBackdrop").classList.contains("hidden")) document.body.classList.remove("no-scroll");
}

function whatsappUrl(message) {
  const number = WHATSAPP_NUMBER.replace(/\D/g,"");
  if (!number || number === "8801XXXXXXXXX" || number.length < 10) {
    showToast("Please set your WhatsApp number in script.js first.");
    return null;
  }
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}
function orderCart() {
  if (!cart.length) return;
  const lines = cart.map((item) => `• ${item.name} x${item.quantity} — ${money(item.price * item.quantity)}`);
  const total = cart.reduce((sum,item) => sum + item.price * item.quantity,0);
  const message = `Hello M Star Watch Gallery! I'd like to order:\n\n${lines.join("\n")}\n\nSubtotal: ${money(total)}\n\nPlease confirm availability, delivery charge and payment details.`;
  const url = whatsappUrl(message);
  if (url) window.open(url,"_blank","noopener,noreferrer");
}
function directOrder(id) {
  const product = products.find((item) => item.id === Number(id));
  if (!product) return;
  const url = whatsappUrl(`Hello M Star Watch Gallery! I'm interested in ${product.name} (${money(product.price)}). Please confirm availability and delivery details.`);
  if (url) window.open(url,"_blank","noopener,noreferrer");
}
let toastTimer;
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"),2800);
}

$("#categoryTabs").addEventListener("click",(event) => {
  const button = event.target.closest("[data-category]");
  if (!button) return;
  activeCategory = button.dataset.category;
  $$(".category-tab").forEach((tab) => tab.classList.toggle("active",tab === button));
  renderProducts();
});
$("#searchInput").addEventListener("input",renderProducts);
$("#sortSelect").addEventListener("change",renderProducts);
$("#searchFocus").addEventListener("click",() => {
  $("#collection").scrollIntoView({behavior:"smooth"});
  setTimeout(() => $("#searchInput").focus(),350);
});
$("#productGrid").addEventListener("click",(event) => {
  const add = event.target.closest("[data-add]");
  const details = event.target.closest("[data-details]");
  if (add) addToCart(add.dataset.add);
  else if (details) openProductDetails(details.dataset.details);
});
$("#productGrid").addEventListener("keydown",(event) => {
  const details = event.target.closest("[data-details]");
  if (details && (event.key === "Enter" || event.key === " ")) {
    event.preventDefault(); openProductDetails(details.dataset.details);
  }
});
$("#productModalContent").addEventListener("click",(event) => {
  const add = event.target.closest("[data-modal-add]");
  const order = event.target.closest("[data-direct-order]");
  if (add) { addToCart(add.dataset.modalAdd); $("#productModalBackdrop").classList.add("hidden"); document.body.classList.remove("no-scroll"); }
  if (order) directOrder(order.dataset.directOrder);
});
$("#closeProductModal").addEventListener("click",() => { $("#productModalBackdrop").classList.add("hidden"); document.body.classList.remove("no-scroll"); });
$("#productModalBackdrop").addEventListener("click",(event) => { if (event.target === $("#productModalBackdrop")) { $("#productModalBackdrop").classList.add("hidden"); document.body.classList.remove("no-scroll"); } });
$("#openCart").addEventListener("click",openCart);
$("#closeCart").addEventListener("click",closeCart);
$("#drawerBackdrop").addEventListener("click",closeCart);
$("#continueShopping").addEventListener("click",closeCart);
$("#cartItems").addEventListener("click",(event) => {
  const quantity = event.target.closest("[data-quantity]");
  const remove = event.target.closest("[data-remove]");
  if (quantity) changeQuantity(quantity.dataset.quantity,Number(quantity.dataset.change));
  if (remove) { cart = cart.filter((item) => item.id !== Number(remove.dataset.remove)); renderCart(); }
});
$("#checkoutWhatsapp").addEventListener("click",orderCart);
$("#contactWhatsapp").addEventListener("click",(event) => {
  event.preventDefault();
  const url = whatsappUrl("Hello M Star Watch Gallery! I'd like help choosing a watch.");
  if (url) window.open(url,"_blank","noopener,noreferrer");
});
$("#menuToggle").addEventListener("click",() => {
  const nav = $("#mainNav");
  const isOpen = nav.classList.toggle("open");
  $("#menuToggle").setAttribute("aria-expanded",String(isOpen));
  $("#menuToggle").textContent = isOpen ? "×" : "☰";
});
$("#mainNav").addEventListener("click",(event) => {
  if (event.target.closest("a")) {
    $("#mainNav").classList.remove("open");
    $("#menuToggle").setAttribute("aria-expanded","false");
    $("#menuToggle").textContent = "☰";
  }
});
$("#adminOpen").addEventListener("click",() => { $("#adminBackdrop").classList.remove("hidden"); document.body.classList.add("no-scroll"); });
$("#closeAdmin").addEventListener("click",() => { $("#adminBackdrop").classList.add("hidden"); document.body.classList.remove("no-scroll"); });
$("#adminBackdrop").addEventListener("click",(event) => { if (event.target === $("#adminBackdrop")) { $("#adminBackdrop").classList.add("hidden"); document.body.classList.remove("no-scroll"); } });
$("#addProductForm").addEventListener("submit",(event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const name = String(form.get("name")).trim();
  const price = Number(form.get("price"));
  if (!name || !Number.isFinite(price) || price < 1) { showToast("Enter a valid product name and price."); return; }
  products.unshift({
    id:nextProductId++,name,price,category:String(form.get("category")),
    tag:"Just added",
    description:String(form.get("description")).trim() || "A fresh addition to the M Star collection.",
    image:String(form.get("image")).trim() || "https://images.unsplash.com/photo-1523170335258-f5ed11844a49?auto=format&fit=crop&w=900&q=85"
  });
  activeCategory = "All";
  $$(".category-tab").forEach((tab) => tab.classList.toggle("active",tab.dataset.category === "All"));
  $("#searchInput").value = "";
  $("#sortSelect").value = "featured";
  renderProducts();
  event.currentTarget.reset();
  $("#adminBackdrop").classList.add("hidden");
  document.body.classList.remove("no-scroll");
  $("#collection").scrollIntoView({behavior:"smooth"});
  showToast("Product added for this session.");
});
document.addEventListener("keydown",(event) => {
  if (event.key === "Escape") {
    closeCart();
    $("#productModalBackdrop").classList.add("hidden");
    $("#adminBackdrop").classList.add("hidden");
    document.body.classList.remove("no-scroll");
  }
});
$("#year").textContent = new Date().getFullYear();
renderProducts();
renderCart();
